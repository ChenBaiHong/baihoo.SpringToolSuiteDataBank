insert into user(objectid,username,password, name,age , balance)values(1, 'user1','12345','baiHoo1' , 20 , 100.00);
insert into user(objectid, username,password, name,age , balance)values(2, 'user2','12345','baiHoo2' , 20 , 100.00);
insert into user(objectid, username,password, name,age , balance)values(3, 'user3','12345','baiHoo3' , 20 , 100.00);
insert into user(objectid, username,password, name,age , balance)values(4, 'user4','12345','baiHoo4' , 20 , 100.00);
insert into user(objectid, username,password, name,age , balance)values(5, 'user5','12345','baiHoo5' , 20 , 100.00);